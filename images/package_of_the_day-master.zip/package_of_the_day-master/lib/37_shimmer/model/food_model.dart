class Food {
  final String title;
  final String urlImage;
  final String description;

  Food( this.title, this.urlImage, this.description);

  
}
