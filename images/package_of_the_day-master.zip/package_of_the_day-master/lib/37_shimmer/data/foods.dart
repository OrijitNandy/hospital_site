import '../model/food_model.dart';

List<Food> allFoods = [
  Food(
    'Apple',
    'assets/images/foods/apple.jpeg',
    'An apple a day keeps your doctors away',
  ),
  Food(
    'Banana',
    'assets/images/foods/banana.jpeg',
    'An Banana a day keeps your doctors away',
  ),
  Food(
    'Orange',
    'assets/images/foods/orange.jpeg',
    'An orange a day keeps your doctors away',
  ),
];
