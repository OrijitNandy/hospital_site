package com.example.package_of_the_day

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
